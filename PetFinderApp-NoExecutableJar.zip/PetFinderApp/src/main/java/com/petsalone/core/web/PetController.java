package com.petsalone.core.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.petsalone.core.domain.Pet;
import com.petsalone.core.domain.PetRepository;

import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

@Controller
public class PetController {
	@Autowired
	private PetRepository repository;

	//private Long petId;
	@RequestMapping("/login")
	public String login() {
    	return "login";
    }	
	
	@RequestMapping("/pets")
	public String index(Model model) {
		//List<Pet> pets = (List<Pet>) repository.findAll();
		List<Pet> pets = (List<Pet>) repository.findAll(Sort.by(Direction.DESC, "lostDate"));
		model.addAttribute("pets", pets);
    	return "pets";
    }
	
    @RequestMapping(value = "add")
    public String addPet(Model model){
    	model.addAttribute("pet", new Pet());
        return "addPet";
    }	

    @RequestMapping(value = "/edit/{id}")
    public String editPet(@PathVariable("id") Long petId, Model model){
    	model.addAttribute("pet", repository.findById(petId));
        return "editPet";
    }	    
    
    @RequestMapping(value = "save", method = RequestMethod.POST)
    public String save(Pet pet){
        repository.save(pet);
    	return "redirect:/pets";
    }
    
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
    public String deletePet(@PathVariable("id") Long petId, Model model) {
    	repository.deleteById(petId);
        return "redirect:/pets";
    }    
    
    @RequestMapping(value = "getpets", method = RequestMethod.GET)
    public @ResponseBody List<Pet> getPets() {
    	//return (List<Pet>)repository.findAll(Sort.by(Sort.Direction.DESC, "pet_name"));
            return (List<Pet>)repository.findAll();
    }      
}
