package com.petsalone.core.domain;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.repository.CrudRepository;

public interface PetRepository extends CrudRepository<Pet, Long> {

    //List<Pet> findByPetName(String name);

	List<Pet> findAll(Sort by);

    
}
