package com.petsalone.core;

import java.util.Date;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.petsalone.core.domain.Pet;
import com.petsalone.core.domain.PetRepository;
import com.petsalone.core.domain.User;
import com.petsalone.core.domain.UserRepository;

@SpringBootApplication
public class PetFinderMainApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(PetFinderMainApplication.class, args);
	}
	
	/**
	 * I am using https://www.browserling.com/tools/bcrypt to generate the password
	 * Save demo users, pets to H2 DB
	 * @param repository
	 * @return
	 */
	@Bean
	public CommandLineRunner demo(PetRepository repository, UserRepository urepository) {
		return (args) -> {
			Date lostDate1 = new Date("2020/05/21");
			Date lostDate2 = new Date("2021/03/22");
			repository.save(new Pet("tommy", "Dog", "Husky", "grey", lostDate2, "Chandra","802219935"));
			repository.save(new Pet("pussy", "Cat", "Wild", "white", lostDate1, "sam","855924123"));

			// Create users with BCrypt encoded password (user/user, admin/admin)
			User user1 = new User("user", "$2a$06$3jYRJrg0ghaaypjZ/.g4SethoeA51ph3UD4kZi9oPkeMTpjKU5uo6", "USER");
			User user2 = new User("admin", "$2a$08$bCCcGjB03eulCWt3CY0AZew2rVzXFyouUolL5dkL/pBgFkUH9O4J2", "ADMIN");
			User user3 = new User("rakesh", "$2a$10$eVNhQ5Fr2N.g6is2ohCdVeyjz.3rvaFd6L5ompo47.nCvNDtMqLzy", "RAKESH");
			User user4 = new User("elmyraduff", "$2a$10$GQT48uRMAxwVdND8az65LuQd3J5Qs/Cb.eMI6kBmkU28BF0YaDBHO", "ADMIN");
			
			urepository.save(user1);
			urepository.save(user2); 
			urepository.save(user3); 
			urepository.save(user4); 
		};
	}
}
