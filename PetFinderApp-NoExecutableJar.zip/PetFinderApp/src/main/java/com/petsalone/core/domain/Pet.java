package com.petsalone.core.domain;

import java.util.Date;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Pet {
	private long id;	 
    
    private String petName;
    private String animalType;
    private String breed;
    private String color; 
    
    @DateTimeFormat(pattern = "yyyy/MM/dd")
    private Date lostDate;
    private String ownerName;
    private String ownerContactNumber;
    
    public Pet() {
    }

	
    public Pet(String petName, String animalType, String breed, String color, Date lostDate, String ownerName,
			String ownerContactNumber) {
		super();
		this.petName = petName;
		this.animalType = animalType;
		this.breed = breed;
		this.color = color;
		this.lostDate = lostDate;
		this.ownerName = ownerName;
		this.ownerContactNumber = ownerContactNumber;
	}


	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@Column(name = "pet_name")
	public String getPetName() {
		return petName;
	}


	public void setPetName(String petName) {
		this.petName = petName;
	}

	@Column(name = "animal_type")
	public String getAnimalType() {
		return animalType;
	}


	public void setAnimalType(String animalType) {
		this.animalType = animalType;
	}

	@Column(name = "breed")
	public String getBreed() {
		return breed;
	}

	public void setBreed(String breed) {
		this.breed = breed;
	}


	@Column(name = "color")
	public String getColor() {
		return color;
	}


	public void setColor(String color) {
		this.color = color;
	}


	@Column(name = "lost_date")
	public Date getLostDate() {
		return lostDate;
	}


	public void setLostDate(Date lostDate) {
		this.lostDate = lostDate;
	}

	@Column(name = "owner_name")
	public String getOwnerName() {
		return ownerName;
	}


	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	@Column(name = "owner_contact_number")
	public String getOwnerContactNumber() {
		return ownerContactNumber;
	}


	public void setOwnerContactNumber(String ownerContactNumber) {
		this.ownerContactNumber = ownerContactNumber;
	}

}
