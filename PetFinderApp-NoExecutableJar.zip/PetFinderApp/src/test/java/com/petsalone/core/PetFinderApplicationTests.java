package com.petsalone.core;

import org.junit.Test;
import org.junit.runner.*;

import static org.junit.Assert.*;

import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.petsalone.core.domain.Pet;
import com.petsalone.core.domain.PetRepository;
import com.petsalone.core.domain.User;
import com.petsalone.core.domain.UserRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
public class PetFinderApplicationTests {


	private UserRepository userRepository;

    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    private PetRepository petRepository;

    @Autowired
    public void setPetRepository(PetRepository petRepository) {
        this.petRepository = petRepository;
    }    
    
    @Test
    public void addUser() {
    	User user = new User("testuser", "testuser", "USER");

    	assertNull(user.getId());
    	userRepository.save(user);
    	assertNotNull(user.getId());
    }
    
	@Test
    public void addPet() {
		Date lostDate2 = new Date("06/22/2021");
		Pet pet = new Pet("tommy", "Dog", "Husky", "grey", lostDate2, "Chandra","802219935");
		
		petRepository.save(pet);
		Optional<Pet> findPet = petRepository.findById(pet.getId());
		assertTrue(findPet.isPresent());
    }
    
}
